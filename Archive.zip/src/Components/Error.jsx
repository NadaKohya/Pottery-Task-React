import React from "react";
export function Error() {
    return ("");
}

