import React from "react";
export function Form() {
    return (  
              <div className="shadow mb-5 bg-white rounded" style={{width:"37em",height:"40em",margin:"auto",marginTop:"3em"}}>
<div>
<img src="https://i.etsystatic.com/21790469/r/il/c91328/3334525105/il_fullxfull.3334525105_ou3f.jpg" style={{width:"37em",height:"25em"}}></img>
    <label style={{fontFamily:"serif",fontSize:"1.2em",marginLeft:"2.3em",marginTop:"1em",marginBottom:".2em"}}>Email</label>
    <input type="text" name="Name" placeholder='Enter ypur email' required="required" className='col-10' style={{marginLeft:"2.6em",marginBottom:"1.2em"}}></input>
    </div>
    <div>
    <label style={{fontFamily:"serif",fontSize:"1.2em",marginLeft:"2.3em",marginBottom:".2em"}}>Password</label>
<input type="number" name="Age" placeholder='Password' required="required" className='col-10' style={{marginLeft:"2.6em",marginBottom:"1.2em"}}></input>
<button value="Submit" className="btn" style={{fontFamily:"'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif",fontWeight:"600",fontSize:"1em",color:"white",marginLeft:"16em",backgroundColor:"goldenrod"}}>Submit</button>
</div>
</div>
    );
}
